/*!

=========================================================
* FFB Dashboard React - v1.0.0
=========================================================

* Product Page: https://www.creative-tim.com/product/FFB-dashboard-react
* Copyright 2019 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/FFB-dashboard-react/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/
import React from "react";
import { Route, Switch } from "react-router-dom";
import AdminNavbar from "components/Navbars/AdminNavbar.jsx";
import Sidebar from "components/Sidebar/Sidebar.jsx";
import Index from "views/Index.jsx";

import routes from "routes.js";
import axios  from 'axios';
import { API_BASE_URL } from '../constants';
import ReactNotification from 'react-notifications-component'
import 'react-notifications-component/dist/theme.css';
import { store } from 'react-notifications-component';


class Admin extends React.Component {
  state = {
    loading: true,
    kpis :[],
    selectedKPI : 0,
    barchart: {},
    detailTable : {},
    historyTable :{},
    query : {
      region: [],
      mill: [],
      supplierName: [],
      doCode: [],
      date :  new Date(),
      type : 'daily'
    }
  }
  componentDidUpdate(e) {
    document.documentElement.scrollTop = 0;
    document.scrollingElement.scrollTop = 0;
    this.refs.mainContent.scrollTop = 0;
  }
  getRoutes = routes => {
    return routes.map((prop, key) => {
      if (prop.layout === "/admin") {
        return (
          <Route
            path={prop.layout + prop.path}
            component={prop.component}
            key={key}
          />
        );
      } else {
        return null;
      }
    });
  };
  getBrandText = path => {
    for (let i = 0; i < routes.length; i++) {
      if (
        this.props.location.pathname.indexOf(
          routes[i].layout + routes[i].path
        ) !== -1
      ) {
        return routes[i].name;
      }
    }
    return "Brand";
  };

  getFilterData = (query=[]) =>{
    //get kpis
    this.getKPIsData(query);
  }

  componentDidMount = async ()=>{
    this.getKPIsData(this.state.query);
  }
  getKPIsData =  async(query=[])=>{
    try {
      let param = {
        'region' : query.region || [],
        'mill' : query.mill || [],
        'supplierName' : query.supplier || [],
        'doCode' : query.docode || [],
        'date' : query.date || new Date(),
      }
      const API_PARAM = query.type || 'daily';
      const kpisResult = await axios.post(`${API_BASE_URL}/card/${API_PARAM}`, param);
      let kpis = kpisResult.data || [];
      if(kpis.length > 0){
        let selectedCard = kpis[this.state.selectedKPI] || {};
        if(selectedCard.apiDetails && selectedCard.apiBar && selectedCard.apiHistory){
          const detailTableResult = await axios.post(`${API_BASE_URL}${selectedCard.apiDetails}`, param);
          const barchartResult = await axios.post(`${API_BASE_URL}${selectedCard.apiBar}`, param);
          const historyTableResult = await axios.post(`${API_BASE_URL}${selectedCard.apiHistory}`, param);
          this.setState({
            query : param,
            kpis : kpis,
            detailTable :  detailTableResult.data || {},
            barchart : barchartResult.data || {},
            historyTable : historyTableResult.data ||{},
            loading : false
          })
        }else{
          this.showError("No KPIs in your system, please contact IT team to check");
        }
      }else{
        this.showError("No KPIs in your system, please contact IT team to check");
      }
    } catch (error) {
      console.log(Object.keys(error), error.message);
      this.showErrorCannotLoadFirstData();
    }
  }

  showError =(message)=>{
    store.addNotification({
      title: "Error!",
      message: message || "System Error, Please contact IT team for support",
      type: "danger",
      insert: "top",
      container: "bottom-center",
      animationIn: ["animated", "fadeIn"],
      animationOut: ["animated", "fadeOut"],
      dismiss: {
        duration: 3000,
        onScreen: true,
        click : false,
        showIcon: true
      }
    });
  }

  showErrorCannotLoadFirstData =()=>{
    store.addNotification({
      title: "Error!",
      message: "System Error, please contact IT team to check",
      type: "danger",
      insert: "top",
      container: "bottom-center",
      animationIn: ["animated", "fadeIn"],
      animationOut: ["animated", "fadeOut"],
      dismiss: {
        click : false,
        showIcon: true,
        duration: 0
      }
    });
  }

  callBackHandleSelectKPI= async(id, api)=>{
    try {
      const detailTableResult = await axios.post(`${API_BASE_URL}${api.apiDetails}`, this.state.query);
      const barchartResult = await axios.post(`${API_BASE_URL}${api.apiBar}`, this.state.query);
      const historyTableResult = await axios.post(`${API_BASE_URL}${api.apiHistory}`, this.state.query);
      this.setState({
        selectedKPI : id,
        detailTable :  detailTableResult.data || {},
        barchart : barchartResult.data || {},
        historyTable : historyTableResult.data ||{}
      })
    } catch (error) {
      console.log(Object.keys(error), error.message);
    }
  }
  render() {
    console.log(this.state.loading)
    if(this.state.loading){
      return (
      <>
      <ReactNotification/>
      <div className="container-fluid">
        <div className="loading-box">
          <div className="middle">
              <div className="d-flex justify-content-center flex-column align-items-center">
                <div className="spinner-border text-primary" role="status">
                  <span className="sr-only">Loading...</span>
                </div>
                <p>Data is loading</p>
            </div>
          </div>
        </div>
      </div>
      </>
      )
    }
    return (
      <>
      <ReactNotification/>
        <Sidebar onFilter={this.getFilterData}
          {...this.props}
          routes={routes}
          logo={{
            innerLink: "/admin/index",
            imgSrc: require("assets/img/brand/FFB-react.png"),
            imgAlt: "..."
          }}
        />
        <div className="main-content" ref="mainContent">
          <AdminNavbar
            {...this.props}
            brandText={this.getBrandText(this.props.location.pathname)}
          />
          <Switch>
            <Route path='/admin/index'
              render= {()=>(<Index 
                kpis={this.state.kpis} 
                query={this.state.query} 
                selectedKPI={this.state.selectedKPI} 
                detailTable={this.state.detailTable}
                barchart = {this.state.barchart}
                historyTable = {this.state.historyTable}
                onSelectKPI={this.callBackHandleSelectKPI}
                loading = {this.state.loading}
                 />)}
              key={0}
            />
          </Switch>
        </div>
      </>
    );
  }
}

export default Admin;
