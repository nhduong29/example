# Notes for DEV


## Select checkboxes
https://jedwatson.github.io/react-select/
https://github.com/Khan/react-multi-select
https://www.npmjs.com/package/react-multiselect-checkboxes

## Select All Solution
https://github.com/JedWatson/react-select/issues/892
https://khan.github.io/react-multi-select/?selectedKind=MultiSelect&selectedStory=default%20view&full=0&addons=1&stories=1&panelRight=0&addonPanel=storybook%2Factions%2Factions-panel

## Datetime picker
https://www.npmjs.com/package/react-datetime

## Table
https://material-table.com/#/docs/features/tree-data
Check-> 
https://github.com/nnajm/orb
https://github.com/davidguttman/react-pivot
https://github.com/tannerlinsley/react-table
http://davidguttman.github.io/react-pivot/
https://react-pivottable.js.org/